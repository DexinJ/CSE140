"""
The `pacai.agents.learning` package contains only agents that learn from their environment,
like Q-learning.
"""
