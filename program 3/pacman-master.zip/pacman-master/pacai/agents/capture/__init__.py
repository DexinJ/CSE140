"""
The `pacai.agents.capture` package contains agents specifically made for the capture game.
"""
