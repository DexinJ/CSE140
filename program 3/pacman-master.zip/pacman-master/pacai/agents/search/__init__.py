"""
The `pacai.agents.search` package contains agents that search their environment
for some specific goal.
"""
