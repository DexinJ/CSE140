"""
The `pacai.core` package contains core elements of the game engine,
and does not contain any code specific to one game.
This package also houses all the layouts for mazes.
"""
