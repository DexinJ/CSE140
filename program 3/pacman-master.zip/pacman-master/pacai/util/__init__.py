"""
The `pacai.util` package contains various utilities used throughout the package,
or useful for students implementing assignment.
"""
