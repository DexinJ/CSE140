def pause():
    """
    Pauses the output stream awaiting user feedback.
    """

    print("<Press enter/return to continue>")
    input()
