"""
The `pacai.ui.pacman` package contains the UI elements for the pacman game.
"""
