"""
The `pacai.ui.gridworld` package contains the UI elements for the gridworld simulation.
"""
