"""
The `pacai.ui.capture` package contains the UI elements for the capture game.
"""
