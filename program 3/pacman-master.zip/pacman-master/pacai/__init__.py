"""
The pacai package is the top-level package for the Pacman AI project maintained by the LINQS
lab at UCSC.
This project originally came from the Berkeley AI Lab.
"""
