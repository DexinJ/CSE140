"""
The `pacai.agents.ghost` package contains only ghost agents.
"""
