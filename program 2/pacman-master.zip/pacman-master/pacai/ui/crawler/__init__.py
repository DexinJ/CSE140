"""
The `pacai.ui.crawler` package contains the UI elements for the crawler demonstration.
"""
