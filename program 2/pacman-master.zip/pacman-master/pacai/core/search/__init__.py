"""
The `pacai.core.search` package contains elements of a general search problem.
"""
